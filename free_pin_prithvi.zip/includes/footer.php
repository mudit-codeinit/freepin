
	<?php
	// Not display where
	if($_VIEW!="checkout" && $_VIEW!="shipping" && $_VIEW!="upsell" && $_VIEW!="thank-you"){
	?>

	<?php }?>
    

	<?php if($_VIEW=="home"){ ?>

	<?php } ?>

	<?php if($_VIEW=="product"){ ?>
		<!-- Product Page Script -->
	<?php } ?>

		<footer class="row justify-content-center footerSection">
		   
		                <div class="col-sm-12" style="margin-top:20px; margin-bottom:20px;">
		                    <div class="row justify-content-center">
		                        <div class="col-sm-2"></div>
		                         <div class="col-md-2 col-sm-12 footer-logo">
                                        <img src="assets/images/logo.jpg" >
                                        </div>
                                <div class="col-md-6 col-sm-12 disc-footer-logo" style="color:#000000ad;padding-top:5px;">
                                     Red State Politics LLC and associates are not affiliated with or sponsored by Donald J. Trump for President. Inc.(campaign)
                                </div>
                                <div class="col-sm-2"></div>
		                    </div>
		                </div>
                       
                    <hr/>
                    
                <div class="col-sm-3">
                    <div class="row justify-content-center" >
                        <!-- <img src="assets/images/Artboard-10.png" class="img-fluid" alt=""> -->
                    </div>
                </div>
                
                <div class="col-sm-12">
                    <div class="row justify-content-center" >
                        <h5 class="txt_gray copyright-text">Trump Train 2020 Pin | Copyright ©2019 | All Rights Reserved</h5>
                    </div>
                </div>
                
                <div class="col-sm-12">
                    <h5 class="row justify-content-center align-items-center margin_B" >
                         <a class="" href="https://stillmypresident.com/pages/about-us" target="_blank"> About Us </a> <span>-</span> <a class="" href="https://stillmypresident.com/pages/privacy-policy" target="_blank">Privacy Policy</a>  <span>-</span> <a class="" href="https://stillmypresident.com/pages/contact-us" target="_blank"> Contact Us </a>
                    </h5>
                </div>                
        </footer>
    </div>

</body>
</html>