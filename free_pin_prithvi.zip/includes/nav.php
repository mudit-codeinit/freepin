
<?php
  // Not display where
  if($_VIEW!="checkout" && $_VIEW!="shipping" && $_VIEW!="upsell" && $_VIEW!="thank-you"){
  ?>
<?php } ?>