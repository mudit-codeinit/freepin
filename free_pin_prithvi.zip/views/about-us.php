        <section class="row justify-content-center we_are_doing">
            <div class="col-md-10"><h2 class="BigTxt">About Us</h2></div>
            <div class="col-md-10">
                <p>Are you ready to re-elect the greatest president in American history for a 2nd term? At StillMyPresident.com our goal is to provide you with the most unique Trump gear that the world has ever seen! Our team of Patriots personally design all our T-Shirts, hats, jewelry, & apparel right here in the USA! We pride ourselves  in providing top notch customer service to bring our unique Trump gear to you in a timely and affordable manner.
                </p>
			</div>
        </section>


    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>